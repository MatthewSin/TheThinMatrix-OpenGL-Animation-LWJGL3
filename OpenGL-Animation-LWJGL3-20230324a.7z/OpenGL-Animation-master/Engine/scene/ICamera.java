package scene;

//import org.lwjgl.util.vector.Matrix4f;
import utils.*;

public interface ICamera {
	
	public Matrix4f getViewMatrix();
	public Matrix4f getProjectionMatrix();
	public Matrix4f getProjectionViewMatrix();
	public void move();

}
