package main;

import static org.lwjgl.glfw.GLFW.*;
//import static org.lwjgl.opengl.ARBFragmentShader.GL_FRAGMENT_SHADER_ARB;
//import static org.lwjgl.opengl.ARBShaderObjects.*;
//import static org.lwjgl.opengl.ARBVertexShader.GL_VERTEX_SHADER_ARB;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryStack.stackPush;
import static org.lwjgl.system.MemoryUtil.*;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Toolkit;
//import java.lang.Math;
import java.nio.ByteBuffer;
//import java.nio.DoubleBuffer;
import java.nio.IntBuffer;

import org.joml.*;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryStack;

//import org.lwjgl.opengl.Display;

import renderEngine.RenderEngine;
import scene.Scene;

public class AnimationApp
{
    private static long window;
    private static int width = 600;
    private static int height = 400;
    private static int mouseX, mouseY;
    private static boolean viewing;

//    private final Matrix4f mat = new Matrix4f();
    private final Quaternionf orientation = new Quaternionf();
//    private final Vector3f position = new Vector3f(0, 2, 5).negate();
    private boolean[] keyDown = new boolean[GLFW_KEY_LAST + 1];
    private static float deltaTime;
    private static GLCapabilities caps;
    private static ByteBuffer buttons;
    private static float deltaX = 0;
    private static float deltaY = 0;
    
    public static int getWidth()
    {
      return width;
    }
    
    public static int getHeight()
    {
      return height;
    }
    
    public static float getFrameTime()
    {
      return deltaTime;
    }
    
    public static GLCapabilities getCaps()
    {
      return caps;
    }
    public static boolean isButtonDown(int button)
    {
      if (button>2 || button<0)
        return false;
      else
        return buttons.get(button)==1;
    }
    public static float getDX()
    {
      return deltaX;
    }
    public static float getDY()
    {
      return deltaY;
    }

    private void run()
    {
      buttons = BufferUtils.createByteBuffer(3);
      if (!glfwInit()) {
        throw new IllegalStateException("Unable to initialize GLFW");
      }
      glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
      glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);
      window = glfwCreateWindow(width, height, "TheThinMatrix OpenGL-Animation", NULL, NULL);
      if (window == NULL) {
        throw new RuntimeException("Failed to create the GLFW window");
      }
      glfwSetKeyCallback(window, (long window1, int key, int scancode, int action, int mods) -> {
        if (key == GLFW_KEY_ESCAPE && action == GLFW_RELEASE) {
          glfwSetWindowShouldClose(window1, true);
        } else if (key >= 0 && key <= GLFW_KEY_LAST) {
          keyDown[key] = action == GLFW_PRESS || action == GLFW_REPEAT;
        }
      });
      glfwSetFramebufferSizeCallback(window, (long window3, int w, int h) -> {
        if (w > 0 && h > 0) {
          width = w;
          height = h;
        }
      });
      glfwSetCursorPosCallback(window, (long window2, double xpos, double ypos) -> {
        if (viewing) {
          deltaX = (float) xpos - mouseX;
          deltaY = (float) ypos - mouseY;
          orientation.rotateLocalX(deltaY * 0.01f).rotateLocalY(deltaX * 0.01f);
        }
        mouseX = (int) xpos;
        mouseY = (int) ypos;
      });
      glfwSetMouseButtonCallback(window, (long window4, int button, int action, int mods) -> {
        if (button == GLFW_MOUSE_BUTTON_1) {
          buttons.put(0, (byte)((action == GLFW_PRESS)?1:0));
        }
        if (button == GLFW_MOUSE_BUTTON_2) {
          buttons.put(1, (byte)((action == GLFW_PRESS)?1:0));
        }
        if (button == GLFW_MOUSE_BUTTON_3) {
          buttons.put(2, (byte)((action == GLFW_PRESS)?1:0));
        }
        if (button == GLFW_MOUSE_BUTTON_1 && action == GLFW_PRESS) {
          viewing = true;
        } else {
          viewing = false;
        }
      });
      try (MemoryStack stack = stackPush()) {
        IntBuffer framebufferSize = stack.mallocInt(2);
        nglfwGetFramebufferSize(window, memAddress(framebufferSize), memAddress(framebufferSize) + 4);
        width = framebufferSize.get(0);
        height = framebufferSize.get(1);
      }
      glfwMakeContextCurrent(window);
      glfwSwapInterval(1);
      caps = GL.createCapabilities();
      if (!caps.GL_ARB_shader_objects)
        throw new UnsupportedOperationException("ARB_shader_objects unsupported");
      if (!caps.GL_ARB_vertex_shader)
        throw new UnsupportedOperationException("ARB_vertex_shader unsupported");
      if (!caps.GL_ARB_fragment_shader)
        throw new UnsupportedOperationException("ARB_fragment_shader unsupported");
//      glClearColor(1, 1, 1, 1);
//      glEnable(GL_BLEND);
//      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      Dimension scrSize = Toolkit.getDefaultToolkit().getScreenSize();
      Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
      int taskBarHeight = scrSize.height - winSize.height;
      glfwSetWindowPos(window, (int)(scrSize.width-width-2), (int)(scrSize.height-height-taskBarHeight-2));
      GL11.glEnable(GL13.GL_MULTISAMPLE);
      RenderEngine engine = RenderEngine.init();
      Scene scene = SceneLoader.loadScene(GeneralSettings.RES_FOLDER);
      glfwShowWindow(window);
      long lastTime = System.nanoTime();
      while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        glViewport(0, 0, width, height);
        glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
        long thisTime = System.nanoTime();
        deltaTime = (thisTime - lastTime) * 1E-9f;
        lastTime = thisTime;
        scene.getCamera().move();
        scene.getAnimatedModel().update();
        engine.renderScene(scene);
//        engine.update();
        glfwSwapBuffers(window);
      }
      engine.close();
    }

/*
    private Matrix4f updateMatrices(float dt)
    {
      float rotateZ = 0f;
      float speed = 2f;
      if (keyDown[GLFW_KEY_LEFT_SHIFT])
        speed = 10f;
      if (keyDown[GLFW_KEY_Q])
        rotateZ -= 1f;
      if (keyDown[GLFW_KEY_E])
        rotateZ += 1f;
      if (keyDown[GLFW_KEY_W])
        position.add(orientation.positiveZ(new Vector3f()).mul(dt * speed));
      orientation.rotateLocalZ(rotateZ * dt * speed);
      return mat.setPerspective((float) Math.toRadians(60), (float) width / height, 0.1f, 1000.0f)
                .rotate(orientation)
                .translate(position);
    }
*/

  /**
   * Initialises the engine and loads the scene. For every frame it updates the
   * camera, updates the animated entity (which updates the animation),
   * renders the scene to the screen, and then updates the display. When the
   * display is close the engine gets cleaned up.
   * 
   * @param args
   */
  public static void main(String[] args)
  {
/*
    RenderEngine engine = RenderEngine.init();
    Scene scene = SceneLoader.loadScene(GeneralSettings.RES_FOLDER);
    while (!Display.isCloseRequested()) {
      scene.getCamera().move();
      scene.getAnimatedModel().update();
      engine.renderScene(scene);
      engine.update();
    }

    engine.close();
*/
    new AnimationApp().run();
  }

}
